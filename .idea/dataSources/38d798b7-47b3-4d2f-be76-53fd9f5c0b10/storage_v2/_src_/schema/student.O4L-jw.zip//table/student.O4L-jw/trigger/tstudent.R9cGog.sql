create definer = root@localhost trigger tstudent
    after insert
    on student
    for each row
begin 
    insert into student_logs(id, operation, operate_time, operate_id, operate_params) 
        values (null, 'insert', now(), new.id, 
                concat('插入的数据为：id=', new.id, ', name=', new.name, ', age=', new.age));
end;

