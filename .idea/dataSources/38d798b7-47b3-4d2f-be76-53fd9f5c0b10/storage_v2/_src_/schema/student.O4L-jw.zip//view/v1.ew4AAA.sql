create definer = root@localhost view v1 as
select `student`.`student`.`id` AS `id`, `student`.`student`.`name` AS `name`
from `student`.`student`
where (`student`.`student`.`id` < '1024040908');

