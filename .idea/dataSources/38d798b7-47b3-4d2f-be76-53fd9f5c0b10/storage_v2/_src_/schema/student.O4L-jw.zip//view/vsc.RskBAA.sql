create definer = root@localhost view vsc as
select `s`.`name` AS `sname`, `s`.`id` AS `sid`, `c`.`name` AS `cname`
from `student`.`student` `s`
         join `student`.`student_course` `sc`
         join `student`.`course` `c`
where ((`s`.`id` = `sc`.`studentid`) and (`sc`.`courseid` = `c`.`id`))
order by `s`.`id`;

