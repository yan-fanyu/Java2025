create definer = root@localhost trigger triger_update_student
    after update
    on student
    for each row
begin 
    insert into student_logs(id, operation, operate_time, operate_id, operate_params) 
        values (null, 'update', now(), new.id, 
                concat('旧的数据为：id=', old.id, ', name=', old.name, ', age=', old.age,
                       ' | 新的数据为：id=', old.id, ', name=', new.name, ', age=', new.age));
end;

