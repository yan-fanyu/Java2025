create definer = root@localhost trigger triger_delete_student
    after delete
    on student
    for each row
begin 
    insert into student_logs(id, operation, operate_time, operate_id, operate_params) 
        values (null, 'delete', now(), old.id, 
                concat('删除之前的数据为：id=', old.id, ', name=', old.name, ', age=', old.age));
end;

