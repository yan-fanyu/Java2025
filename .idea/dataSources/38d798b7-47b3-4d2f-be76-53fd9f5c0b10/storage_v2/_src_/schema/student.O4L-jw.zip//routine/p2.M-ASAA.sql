create
    definer = root@localhost procedure p2()
begin 
    declare scount int default 0;
    select count(*) into scount from student;
    select scount;
end;

